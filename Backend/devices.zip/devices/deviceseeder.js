var Device = require('../models/device');

var mongoose = require('mongoose');

mongoose.connect('localhost:27017/devices');

var devices = [
    new Device({
        "deviceId": "65",
        "name": "SJ-Device-7",
        "networkSlave1": "3",
        "networkSlave2": "1",
        "deviceType": "chillerController",
        "driverType": 0,
        "communicationCategory": "CHL",
        "communicationType": "MB"
    }),
    new Device({
        "deviceId": "66",
        "name": "SJ-Device-8",
        "networkSlave1": "3",
        "networkSlave2": "3",
        "deviceType": "chillerController",
        "driverType": 0,
        "communicationCategory": "CHL",
        "communicationType": "MB"
    }),
    new Device({
        "deviceId": "67",
        "name": "SJ-Device-9",
        "networkSlave1": "3",
        "networkSlave2": "4",
        "deviceType": "em",
        "driverType": 0,
        "communicationCategory": "EM",
        "communicationType": "MB"
    }),
    new Product({
        "deviceId": "68",
        "name": "SJ-Device-10",
        "networkSlave1": "3",
        "networkSlave2": "5",
        "deviceType": "em",
        "driverType": 0,
        "communicationCategory": "EM",
        "communicationType": "MB"
    }),
    new Product({
        imagePath: 'https://d1r7xvmnymv7kg.cloudfront.net/sites_products/darksouls3/assets/img/DARKSOUL_facebook_mini.jpg',
        title: 'Dark Souls 3 Video Game',
        description: 'I died!',
        price: 50
    })
];

var done = 0;
for (var i = 0; i < products.length; i++) {
    products[i].save(function(err, result) {
        done++;
        if (done === products.length) {
            exit();
        }
    });
}

function exit() {
    mongoose.disconnect();
}