var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var schema = new Schema({
    deviceId: {type: String, required:'true'},
    name: {type: String, required: true},
    networkSlave1: {type: number, required: true},
    networkSlave2: {type: number, required: true},
    deviceType: {type: String, required: true},
    driverType:  {type:number,required:true},
communicationCategory:  {type:String,required:true},
"communicationType":  {type:String,required:true},

});

module.exports = mongoose.model('Device', schema);